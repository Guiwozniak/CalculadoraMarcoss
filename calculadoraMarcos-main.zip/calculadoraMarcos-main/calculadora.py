import tkinter as tk
import math

# Cor de fundo principal da calculadora
COR_FUNDO = "#212121"

# Define as cores de fundo e texto dos botões com base no texto do botão
def cor_botao(texto):
    if texto in ["DEL", "AC", "On", "Alpha"]:
        return {"bg": "#E53935", "fg": "#FFFFFF"}  # Botões vermelhos
    elif texto == "Shift":
        return {"bg": "#424242", "fg": "#FFFFFF"}  # Cinza escuro
    elif texto == "Replay":
        return {"bg": "#BDBDBD", "fg": "#000000"}  # Cinza claro
    elif texto in ["=", "0","1","2","3","4","5","6","7","8","9",".",",","Ans","EXP","+","-","X","÷"]:
        return {"bg": "#E0E0E0", "fg": "#000000"}  # Números e operadores claros
    else:
        return {"bg": "#424242", "fg": "#FFFFFF"}  # Outros botões padrão

# Inicializa a janela principal da calculadora
calc = tk.Tk()
calc.title("Calculadora Científica")
calc.configure(bg=COR_FUNDO)
calc.geometry("529x900")         # Tamanho fixo da janela
calc.resizable(False, False)     # Impede redimensionamento

# Variável de controle do display e expressão atual da conta
var = tk.StringVar(value="0")
expressao = ""

# Campo de entrada (display da calculadora)
display = tk.Entry(calc, textvariable=var, font=("Arial", 34), bd=10, insertwidth=2, width=14,
                   borderwidth=4, relief="ridge", justify="right", bg="white")
display.grid(row=0, column=0, columnspan=6, pady=10, padx=10)

# Formata um número para o padrão brasileiro: separador de milhar com ponto e decimal com vírgula
def formatar_numero(valor):
    try:
        if "Erro" in valor:
            return valor
        # Troca temporária para facilitar a troca de vírgulas e pontos
        valor = valor.replace(".", "#").replace(",", ".").replace("#", ",")
        if "." in valor:
            inteiro, decimal = valor.split(".")
        else:
            inteiro, decimal = valor, ""
        # Formata parte inteira com separador de milhares '.'
        inteiro_formatado = "{:,}".format(int(inteiro)).replace(",", ".")
        if decimal:
            return f"{inteiro_formatado},{decimal}"
        return inteiro_formatado
    except:
        return valor

# Limpa toda a expressão e o display
def limpar():
    global expressao
    expressao = ""
    var.set("0")

# Limpa apenas o campo de entrada (sem apagar a expressão completa)
def limpar_entrada():
    var.set("0")

# Realiza o cálculo da expressão matemática armazenada na variável global expressao
def calcular():
    global expressao
    try:
        # Substitui operadores personalizados pelos operadores do Python
        resultado = eval(expressao.replace("÷", "/").replace("X", "*"))
        # Trata divisão por zero que resulta em infinito
        if resultado == float('inf') or resultado == float('-inf'):
            raise ZeroDivisionError
        resultado_str = str(round(resultado, 10)).replace(".", ",")
        var.set(formatar_numero(resultado_str))  # Exibe resultado formatado
        expressao = str(resultado)  # Atualiza a expressão com o resultado para novos cálculos
    except ZeroDivisionError:
        var.set("Erro")
        expressao = ""
    except Exception:
        var.set("Erro")
        expressao = ""

# Função que trata todos os cliques nos botões e manipula a expressão ou display conforme o valor
def clique(valor):
    global expressao
    if valor in "0123456789":  # Dígitos
        atual = var.get().replace(".", "")
        if atual == "0":
            novo = valor
        else:
            novo = atual + valor
        var.set(formatar_numero(novo))
    
    elif valor == ",":  # Vírgula decimal
        atual = var.get().replace(".", "")
        if "," in atual:
            return
        if atual == "" or atual == "0":
            var.set("0,")
        else:
            var.set(formatar_numero(atual + ","))

    elif valor in ["+", "-", "X", "÷"]:  # Operadores
        if expressao and expressao[-1] in "+-*/":
            expressao = expressao[:-1]  # Evita operadores duplicados
        entrada = var.get().replace(".", "").replace(",", ".")
        expressao += entrada + valor.replace("X", "*").replace("÷", "/")
        var.set("")

    elif valor == "=":  # Igual
        entrada = var.get().replace(".", "").replace(",", ".")
        expressao += entrada
        calcular()

    elif valor == "C":  # Limpa tudo (expressão + display)
        limpar()

    elif valor == "AC":  # Limpa apenas o campo atual
        limpar_entrada()

    elif valor == "DEL":  # Apagar último caractere do display
        atual = var.get().replace(".", "")
        if len(atual) > 1:
            var.set(formatar_numero(atual[:-1]))
        else:
            var.set("0")

    elif valor == "x²":  # Potência ao quadrado
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = num ** 2
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")
    
    elif valor == "√":
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = math.sqrt(num)
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")
    elif valor == "log":
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = math.log(num, 10)
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    
    elif valor == "^":  # Potência
     entrada = var.get().replace(".", "").replace(",", ".")
     expressao += entrada + "**"
     var.set(entrada + "^")
           
 

    elif valor == "²√x":  # Raiz quadrada
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            if num < 0:
                raise ValueError
            resultado = num ** 0.5
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    elif valor == "1/x":  # Inverso
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            if num == 0:
                raise ZeroDivisionError
            resultado = 1 / num
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    elif valor == "%":  # Porcentagem
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = num / 100
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    elif valor == "log":
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = math.log(num, 10)
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    elif valor == "ln":
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            resultado = math.log(num)   # log natural (base e)
            var.set(formatar_numero(str(round(resultado, 10)).replace(".", ",")))
        except:
            var.set("Erro")

    elif valor == "ab/c":
        try:
            num = float(var.get().replace(".", "").replace(",", "."))
            # converte em fração
            denominador = 1000000  # precisão
            numerador = round(num * denominador)
            from math import gcd
            mdc = gcd(numerador, denominador)
            numerador //= mdc
            denominador //= mdc
            if denominador == 1:
                var.set(str(numerador))
            else:
                var.set(f"{numerador}/{denominador}")
        except:
            var.set("Erro")


# Cria um botão retangular na interface com texto, posição e tamanho especificados
def criar_botao(texto, linha, coluna, span, largura):
    cores = cor_botao(texto)
    tk.Button(calc, text=texto, padx=20, pady=20, width=largura, font=("Arial", 12),
              bg=cores["bg"], fg=cores["fg"], relief="raised", bd=3,
              command=lambda t=texto: clique(t)) \
        .grid(row=linha, column=coluna, columnspan=span, padx=5, pady=5)

# Cria um botão circular usando canvas (usado para o botão "Replay")
def criar_botao_redondo(canvas, x, y, raio, texto, comando):
    cores = cor_botao(texto)
    oval = canvas.create_oval(
        x - raio, y - raio, x + raio, y + raio,
        fill=cores["bg"], outline=""
    )
    text_id = canvas.create_text(
        x, y, text=texto, fill=cores["fg"], font=("Arial", 10, "bold")
    )

    def clique_evento(event):
        comando()

    canvas.tag_bind(oval, "<Button-1>", clique_evento)
    canvas.tag_bind(text_id, "<Button-1>", clique_evento)

# Lista de botões retangulares adicionais com suas posições e tamanhos na grade
botoes_retangulares = [
    ("Shift", 1, 0, 1, 3), ("Alpha", 1, 1, 1, 3),
    ("Modeclr", 1, 4, 1, 3), ("On", 1, 5, 1, 3),
    ("x⁻¹", 2, 0, 1, 3), ("nCr", 2, 1, 1, 3), ("Pol( )", 2, 4, 1, 3), ("x³", 2, 5, 1, 3),
    ("ab/c", 3, 0, 1, 3), ("√", 3, 1, 1, 3), ("x²", 3, 2, 1, 3), ("^", 3, 3, 1, 3), ("log", 3, 4, 1, 3), ("ln", 3, 5, 1, 3),
    ("(-)", 4, 0, 1, 3), ("., ,,", 4, 1, 1, 3), ("hyp", 4, 2, 1, 3), ("sin", 4, 3, 1, 3), ("cos", 4, 4, 1, 3), ("tan", 4, 5, 1, 3),
    ("RCL", 5, 0, 1, 3), ("ENG", 5, 1, 1, 3), ("(", 5, 2, 1, 3), (")", 5, 3, 1, 3), (",", 5, 4, 1, 3), ("m+", 5, 5, 1, 3),
]

# Cria todos os botões retangulares definidos na lista acima
for (texto, linha, coluna, span, largura) in botoes_retangulares:
    criar_botao(texto, linha, coluna, span, largura)

# Configurações para a grade que conterá o teclado numérico
calc.grid_rowconfigure(6, weight=0)
teclado = tk.Frame(calc, bg=COR_FUNDO, height=300)
teclado.grid(row=6, column=0, columnspan=6, sticky="nsew", padx=5, pady=(5, 5))

# Define o layout do teclado numérico com 4 linhas e 5 colunas
for r in range(4):
    teclado.grid_rowconfigure(r, weight=1, uniform="linhas")
for c in range(5):
    teclado.grid_columnconfigure(c, weight=1, uniform="colunas")

# Função para criar botões no teclado numérico
def criar_botao_teclado(texto, r, c, rs=1, cs=1):
    cores = cor_botao(texto)
    tk.Button(teclado, text=texto, font=("Arial", 12, "bold"), width=9, height=3,
              bg=cores["bg"], fg=cores["fg"], relief="raised", bd=2,
              command=lambda t=texto: clique(t)) \
        .grid(row=r, column=c, rowspan=rs, columnspan=cs, padx=2, pady=2)

# Cria os botões numéricos e operadores no teclado
criar_botao_teclado("7", 0, 0)
criar_botao_teclado("8", 0, 1)
criar_botao_teclado("9", 0, 2)
criar_botao_teclado("DEL", 0, 3)
criar_botao_teclado("AC", 0, 4)

criar_botao_teclado("4", 1, 0)
criar_botao_teclado("5", 1, 1)
criar_botao_teclado("6", 1, 2)
criar_botao_teclado("X", 1, 3)
criar_botao_teclado("÷", 1, 4)

criar_botao_teclado("1", 2, 0)
criar_botao_teclado("2", 2, 1)
criar_botao_teclado("3", 2, 2)
criar_botao_teclado("+", 2, 3)
criar_botao_teclado("-", 2, 4)

criar_botao_teclado("0", 3, 0)
criar_botao_teclado(".", 3, 1)
criar_botao_teclado("EXP", 3, 2)
criar_botao_teclado("Ans", 3, 3)
criar_botao_teclado("=", 3, 4)

# Criação do botão redondo "Replay" em canvas
tamanho_largura = 140
tamanho_altura = 160
raio_replay = 70

canvas_replay = tk.Canvas(calc, width=tamanho_largura, height=tamanho_altura, bg=COR_FUNDO, highlightthickness=0)
canvas_replay.place(x=190, y=80)
criar_botao_redondo(canvas_replay, tamanho_largura//2, tamanho_altura//2, raio_replay, "Replay", lambda: clique("Replay"))

# Executa o loop principal da interface gráfica
calc.mainloop()
